/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.125, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5, 500, 1500, "https://api.fishbowlonline.com/v1/auth/authenticate"], "isController": false}, {"data": [0.0, 500, 1500, "https://api.fishbowlonline.com/v1/picks/379/commit?expand=pickItems.salesOrderItem.saleItem.images,pickItems.pickFromLocation,pickItems.pickToLocation,pickItems.item.images,pickItems.workOrderItem,pickItems.item.itemTrackingTypes.trackingType,pickItems.salesOrderItem.saleItem,pickItems.item.tags,pickItems.salesOrderItem.salesOrder.representative,pickItems.salesOrderItem.salesOrder.customer,pickItems.salesOrderItem.salesOrder.paymentTerm,pickBundleItems.pickItems.salesOrderItem.saleItem.images,pickBundleItems.pickItems.pickFromLocation,pickBundleItems.pickItems.item.images,pickBundleItems.pickItems.item.defaultUom,pickBundleItems.pickItems.item.tags,pickBundleItems.pickItems.item.itemTrackingTypes.trackingType,pickBundleItems.pickItems.salesOrderItem.saleItem,pickBundleItems.pickItems.salesOrderItem.salesOrder.representative,pickBundleItems.pickItems.salesOrderItem.salesOrder.customer,pickBundleItems.pickItems.salesOrderItem.salesOrder.paymentTerm"], "isController": false}, {"data": [0.0, 500, 1500, "https://api.fishbowlonline.com/v1/picks/379?expand=pickItems.salesOrderItem.saleItem.images,pickItems.pickFromLocation,pickItems.pickToLocation,pickItems.item.images,pickItems.workOrderItem,pickItems.item.itemTrackingTypes.trackingType,pickItems.salesOrderItem.saleItem,pickItems.item.tags,pickItems.salesOrderItem.salesOrder.representative,pickItems.salesOrderItem.salesOrder.customer,pickItems.salesOrderItem.salesOrder.paymentTerm,pickBundleItems.pickItems.salesOrderItem.saleItem.images,pickBundleItems.pickItems.pickFromLocation,pickBundleItems.pickItems.item.images,pickBundleItems.pickItems.item.defaultUom,pickBundleItems.pickItems.item.tags,pickBundleItems.pickItems.item.itemTrackingTypes.trackingType,pickBundleItems.pickItems.salesOrderItem.saleItem,pickBundleItems.pickItems.salesOrderItem.salesOrder.representative,pickBundleItems.pickItems.salesOrderItem.salesOrder.customer,pickBundleItems.pickItems.salesOrderItem.salesOrder.paymentTerm"], "isController": false}, {"data": [0.0, 500, 1500, "pick"], "isController": true}, {"data": [0.0, 500, 1500, "https://api.fishbowlonline.com/v1/picks/379/finish?expand=pickItems.salesOrderItem.saleItem.images,pickItems.pickFromLocation,pickItems.pickToLocation,pickItems.item.images,pickItems.workOrderItem,pickItems.item.itemTrackingTypes.trackingType,pickItems.salesOrderItem.saleItem,pickItems.item.tags,pickItems.salesOrderItem.salesOrder.representative,pickItems.salesOrderItem.salesOrder.customer,pickItems.salesOrderItem.salesOrder.paymentTerm,pickBundleItems.pickItems.salesOrderItem.saleItem.images,pickBundleItems.pickItems.pickFromLocation,pickBundleItems.pickItems.item.images,pickBundleItems.pickItems.item.defaultUom,pickBundleItems.pickItems.item.tags,pickBundleItems.pickItems.item.itemTrackingTypes.trackingType,pickBundleItems.pickItems.salesOrderItem.saleItem,pickBundleItems.pickItems.salesOrderItem.salesOrder.representative,pickBundleItems.pickItems.salesOrderItem.salesOrder.customer,pickBundleItems.pickItems.salesOrderItem.salesOrder.paymentTerm"], "isController": false}, {"data": [0.0, 500, 1500, "start"], "isController": false}, {"data": [0.0, 500, 1500, "picks"], "isController": false}, {"data": [0.5, 500, 1500, "login"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 6, 0, 0.0, 10132.833333333332, 1492, 37170, 3078.5, 37170.0, 37170.0, 37170.0, 0.09857396333048564, 53.85538108591542, 0.2579865446540054], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://api.fishbowlonline.com/v1/auth/authenticate", 1, 0, 0.0, 1492.0, 1492, 1492, 1492.0, 1492.0, 1492.0, 1492.0, 0.6702412868632708, 3.7530893934316354, 0.3770107238605898], "isController": false}, {"data": ["https://api.fishbowlonline.com/v1/picks/379/commit?expand=pickItems.salesOrderItem.saleItem.images,pickItems.pickFromLocation,pickItems.pickToLocation,pickItems.item.images,pickItems.workOrderItem,pickItems.item.itemTrackingTypes.trackingType,pickItems.salesOrderItem.saleItem,pickItems.item.tags,pickItems.salesOrderItem.salesOrder.representative,pickItems.salesOrderItem.salesOrder.customer,pickItems.salesOrderItem.salesOrder.paymentTerm,pickBundleItems.pickItems.salesOrderItem.saleItem.images,pickBundleItems.pickItems.pickFromLocation,pickBundleItems.pickItems.item.images,pickBundleItems.pickItems.item.defaultUom,pickBundleItems.pickItems.item.tags,pickBundleItems.pickItems.item.itemTrackingTypes.trackingType,pickBundleItems.pickItems.salesOrderItem.saleItem,pickBundleItems.pickItems.salesOrderItem.salesOrder.representative,pickBundleItems.pickItems.salesOrderItem.salesOrder.customer,pickBundleItems.pickItems.salesOrderItem.salesOrder.paymentTerm", 1, 0, 0.0, 37170.0, 37170, 37170, 37170.0, 37170.0, 37170.0, 37170.0, 0.02690341673392521, 11.14227073244552, 0.1395352014393328], "isController": false}, {"data": ["https://api.fishbowlonline.com/v1/picks/379?expand=pickItems.salesOrderItem.saleItem.images,pickItems.pickFromLocation,pickItems.pickToLocation,pickItems.item.images,pickItems.workOrderItem,pickItems.item.itemTrackingTypes.trackingType,pickItems.salesOrderItem.saleItem,pickItems.item.tags,pickItems.salesOrderItem.salesOrder.representative,pickItems.salesOrderItem.salesOrder.customer,pickItems.salesOrderItem.salesOrder.paymentTerm,pickBundleItems.pickItems.salesOrderItem.saleItem.images,pickBundleItems.pickItems.pickFromLocation,pickBundleItems.pickItems.item.images,pickBundleItems.pickItems.item.defaultUom,pickBundleItems.pickItems.item.tags,pickBundleItems.pickItems.item.itemTrackingTypes.trackingType,pickBundleItems.pickItems.salesOrderItem.saleItem,pickBundleItems.pickItems.salesOrderItem.salesOrder.representative,pickBundleItems.pickItems.salesOrderItem.salesOrder.customer,pickBundleItems.pickItems.salesOrderItem.salesOrder.paymentTerm", 1, 0, 0.0, 2763.0, 2763, 2763, 2763.0, 2763.0, 2763.0, 2763.0, 0.3619254433586681, 149.57770652370613, 0.607214757509953], "isController": false}, {"data": ["pick", 1, 0, 0.0, 59305.0, 59305, 59305, 59305.0, 59305.0, 59305.0, 59305.0, 0.01686198465559396, 55.180334315192646, 0.2553009864261023], "isController": true}, {"data": ["https://api.fishbowlonline.com/v1/picks/379/finish?expand=pickItems.salesOrderItem.saleItem.images,pickItems.pickFromLocation,pickItems.pickToLocation,pickItems.item.images,pickItems.workOrderItem,pickItems.item.itemTrackingTypes.trackingType,pickItems.salesOrderItem.saleItem,pickItems.item.tags,pickItems.salesOrderItem.salesOrder.representative,pickItems.salesOrderItem.salesOrder.customer,pickItems.salesOrderItem.salesOrder.paymentTerm,pickBundleItems.pickItems.salesOrderItem.saleItem.images,pickBundleItems.pickItems.pickFromLocation,pickBundleItems.pickItems.item.images,pickBundleItems.pickItems.item.defaultUom,pickBundleItems.pickItems.item.tags,pickBundleItems.pickItems.item.itemTrackingTypes.trackingType,pickBundleItems.pickItems.salesOrderItem.saleItem,pickBundleItems.pickItems.salesOrderItem.salesOrder.representative,pickBundleItems.pickItems.salesOrderItem.salesOrder.customer,pickBundleItems.pickItems.salesOrderItem.salesOrder.paymentTerm", 1, 0, 0.0, 13215.0, 13215, 13215, 13215.0, 13215.0, 13215.0, 13215.0, 0.07567158531971245, 31.391958120507, 0.39247245081346954], "isController": false}, {"data": ["start", 1, 0, 0.0, 3044.0, 3044, 3044, 3044.0, 3044.0, 3044.0, 3044.0, 0.328515111695138, 136.01712641672142, 0.5803553096254928], "isController": false}, {"data": ["picks", 1, 0, 0.0, 3113.0, 3113, 3113, 3113.0, 3113.0, 3113.0, 3113.0, 0.32123353678124, 519.160764836974, 0.42506976790876966], "isController": false}, {"data": ["login", 1, 0, 0.0, 1492.0, 1492, 1492, 1492.0, 1492.0, 1492.0, 1492.0, 0.6702412868632708, 3.7530893934316354, 0.3770107238605898], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 6, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
