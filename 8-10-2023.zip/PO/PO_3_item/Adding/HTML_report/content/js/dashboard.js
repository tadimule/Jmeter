/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6666666666666666, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "purchase_order_settings? "], "isController": false}, {"data": [0.5, 500, 1500, "https://api.fishbowlonline.com/v1/auth/authenticate"], "isController": false}, {"data": [0.0, 500, 1500, "https://api.fishbowlonline.com/v1/purchase_orders?quickSearchValue=&quickSearchColumns=number,purchaseOrderStatus,vendor.name,buyer.firstName&expand=buyer,purchaseOrderItems&pageNumber=1&pageSize=25&orderBy=number&ascending=false"], "isController": false}, {"data": [1.0, 500, 1500, "https://api.fishbowlonline.com/v1/purchase_orders?expand=purchaseOrderItems.item.images,purchaseOrderItems.item.vendorItems,purchaseOrderItems.item.itemTrackingTypes,purchaseOrderItems.item.defaultUom.fromConversions,purchaseOrderItems.item.defaultUom.toConversions,vendor.currency"], "isController": false}, {"data": [1.0, 500, 1500, "issue"], "isController": false}, {"data": [1.0, 500, 1500, "https://api.fishbowlonline.com/v1/purchase_orders/37?expand=purchaseOrderItems.item.images,purchaseOrderItems.item.vendorItems,purchaseOrderItems.item.itemTrackingTypes,purchaseOrderItems.item.defaultUom.fromConversions,purchaseOrderItems.item.defaultUom.toConversions,vendor.currency"], "isController": false}, {"data": [0.5, 500, 1500, "login"], "isController": true}, {"data": [1.0, 500, 1500, "next_po_number"], "isController": false}, {"data": [0.0, 500, 1500, "po"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7, 0, 0.0, 570.7142857142857, 210, 1795, 305.0, 1795.0, 1795.0, 1795.0, 1.746506986027944, 696.5107870197106, 1.9606782528692615], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["purchase_order_settings? ", 1, 0, 0.0, 210.0, 210, 210, 210.0, 210.0, 210.0, 210.0, 4.761904761904763, 4.715401785714286, 3.7202380952380953], "isController": false}, {"data": ["https://api.fishbowlonline.com/v1/auth/authenticate", 1, 0, 0.0, 837.0, 837, 837, 837.0, 837.0, 837.0, 837.0, 1.194743130227001, 6.690094832735962, 0.6708762694145759], "isController": false}, {"data": ["https://api.fishbowlonline.com/v1/purchase_orders?quickSearchValue=&quickSearchColumns=number,purchaseOrderStatus,vendor.name,buyer.firstName&expand=buyer,purchaseOrderItems&pageNumber=1&pageSize=25&orderBy=number&ascending=false", 1, 0, 0.0, 1795.0, 1795, 1795, 1795.0, 1795.0, 1795.0, 1795.0, 0.5571030640668524, 1525.572880396936, 0.5228281685236769], "isController": false}, {"data": ["https://api.fishbowlonline.com/v1/purchase_orders?expand=purchaseOrderItems.item.images,purchaseOrderItems.item.vendorItems,purchaseOrderItems.item.itemTrackingTypes,purchaseOrderItems.item.defaultUom.fromConversions,purchaseOrderItems.item.defaultUom.toConversions,vendor.currency", 1, 0, 0.0, 376.0, 376, 376, 376.0, 376.0, 376.0, 376.0, 2.6595744680851063, 40.85979055851064, 7.261884973404255], "isController": false}, {"data": ["issue", 1, 0, 0.0, 305.0, 305, 305, 305.0, 305.0, 305.0, 305.0, 3.278688524590164, 50.5186987704918, 3.550845286885246], "isController": false}, {"data": ["https://api.fishbowlonline.com/v1/purchase_orders/37?expand=purchaseOrderItems.item.images,purchaseOrderItems.item.vendorItems,purchaseOrderItems.item.itemTrackingTypes,purchaseOrderItems.item.defaultUom.fromConversions,purchaseOrderItems.item.defaultUom.toConversions,vendor.currency", 1, 0, 0.0, 239.0, 239, 239, 239.0, 239.0, 239.0, 239.0, 4.184100418410042, 64.46946914225941, 4.159584205020921], "isController": false}, {"data": ["login", 1, 0, 0.0, 837.0, 837, 837, 837.0, 837.0, 837.0, 837.0, 1.194743130227001, 6.690094832735962, 0.6708762694145759], "isController": true}, {"data": ["next_po_number", 1, 0, 0.0, 233.0, 233, 233, 233.0, 233.0, 233.0, 233.0, 4.291845493562231, 1.8986386802575106, 3.302709227467811], "isController": false}, {"data": ["po", 1, 0, 0.0, 3158.0, 3158, 3158, 3158.0, 3158.0, 3158.0, 3158.0, 0.31665611146295125, 882.2088742875238, 2.3106000633312225], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
